exports.getAddNewStudentPage = (req, res) => {
    res.render('Home', { title: 'Add new student' });
};
